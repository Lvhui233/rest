---
layout: default
title: About Vinit Kumar
---

{{site.about}}